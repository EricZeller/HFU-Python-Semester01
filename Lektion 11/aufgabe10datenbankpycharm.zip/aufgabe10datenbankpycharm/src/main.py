import hauptprogramm
hauptprogramm.mainloop()